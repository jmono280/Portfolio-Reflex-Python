
## Portafolio

Pagina estatica creada en reflex para mostrar experiencias y habilidades en un CV.

## Proyecto

# Basado en 
### MoureDev

[(https://github.com/mouredev/portafolio-template.git)(https://github.com/mouredev)
